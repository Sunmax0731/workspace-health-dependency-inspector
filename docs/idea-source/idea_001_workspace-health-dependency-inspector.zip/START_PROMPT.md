あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: VSCodeExtension
- No.: 1
- 分野: 状態・構造理解
- アイデア: ワークスペース状態・依存・健康診断
- リポジトリ名: workspace-health-dependency-inspector

## 元アイデア

- 概要: コード作業状態、依存関係、モノレポ構造、ビルド時間、未追跡、README状態をまとめて診断する。
- 課題: プロジェクトの劣化サインや構造情報が複数箇所に散らばり、作業前に把握しづらい。
- 類似サービス・アプリ: GitLens, Sourcegraph, Dependency Cruiser, Project Manager
- 差別化ポイント: ワークスペースの状態と次の改善候補を軽量な定期診断として出す。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
