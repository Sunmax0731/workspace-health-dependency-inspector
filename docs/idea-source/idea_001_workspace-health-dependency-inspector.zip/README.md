# ワークスペース状態・依存・健康診断 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | VSCodeExtension |
| No. | 1 |
| 分野 | 状態・構造理解 |
| アイデア | ワークスペース状態・依存・健康診断 |
| リポジトリ名 | workspace-health-dependency-inspector |
| 概要 | コード作業状態、依存関係、モノレポ構造、ビルド時間、未追跡、README状態をまとめて診断する。 |
| 課題 | プロジェクトの劣化サインや構造情報が複数箇所に散らばり、作業前に把握しづらい。 |
| 類似サービス・アプリ | GitLens, Sourcegraph, Dependency Cruiser, Project Manager |
| 差別化ポイント | ワークスペースの状態と次の改善候補を軽量な定期診断として出す。 |

## 目的

このZIPには、`VSCodeExtension` 領域のアイデア `ワークスペース状態・依存・健康診断` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
